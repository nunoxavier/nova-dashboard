cd /home/pi/consultDash/
npm start
